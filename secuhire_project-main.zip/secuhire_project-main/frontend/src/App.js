import React, { useState, useEffect, useRef, useCallback } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { Badge } from "./components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Textarea } from "./components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { Progress } from "./components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "./components/ui/alert";
import { 
  Shield, Users, Briefcase, TrendingUp, Plus, Search, Filter, 
  MapPin, DollarSign, Calendar, Phone, Mail, FileText, 
  ChevronRight, Star, Clock, CheckCircle, User, Edit,
  BarChart3, PieChart, Target, Award, Zap, Brain, Building2,
  Eye, Heart, Send, Video, AlertTriangle, Verified, Lock,
  Camera, Monitor, X, ExternalLink, Copy, Volume2, Timer,
  GraduationCap, Award as AwardIcon, Briefcase as BriefcaseIcon,
  Globe, Users2, BookOpen, CheckCircle2, RefreshCw, Calendar as CalendarIcon,
  LogOut
} from "lucide-react";
import SecureInterview from "./components/SecureInterview";
import SecureInterviewSession from "./components/SecureInterviewSession";
import ProctorSetup from "./components/ProctorSetup";
import PhoneJoinPage from "./components/PhoneJoinPage";
import InterviewerProctor from "./components/InterviewerProctor";
import RecordingsViewer from "./components/RecordingsViewer";
import RecruiterInterviews from "./components/RecruiterInterviews";
import "./App.css";
import VideoUpload from "./components/VideoUpload";
import VideoList from "./components/VideoList";
import AptitudeApp from "./modules/aptitude/AptitudeApp";

const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const API = `${API_BASE}/api`;

// Auth Context for Both Recruiters and Candidates
const AuthContext = React.createContext();

// Shared helper: download candidate resume
const downloadResume = async (candidateId, candidateName) => {
  try {
    const resp = await axios.get(`${API}/candidates/${candidateId}/resume`, {
      responseType: 'blob',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` }
    });
    const blob = new Blob([resp.data]);
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${candidateName || 'candidate'}_resume`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
  } catch (error) {
    const msg = error.response?.data?.detail || (error.response?.status === 403
      ? 'Resume is accessible only when the candidate has applied to your company.'
      : 'Resume not available');
    alert(msg);
  }
};

// Dedicated Pricing Page
const PricingPage = () => {
  const navigate = useNavigate();

  const handleChoosePlan = (plan) => {
    try {
      // Placeholder: integrate Sentra payment modal and subscription flow here.
      alert(`Selected plan: ${plan.label} (₹${plan.amount})`);
    } catch (e) {
      console.error('Plan selection error:', e);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-slate-50 to-purple-50/40">
      {/* Header */}
      <header className="px-6 py-4 border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Shield className="w-8 h-8 text-purple-600" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-pulse"></div>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-teal-600 to-orange-500 bg-clip-text text-transparent">SecuHire</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              className="border-slate-300 text-slate-700 hover:bg-slate-50"
              onClick={() => navigate('/')}
            >
              Back to Home
            </Button>
          </div>
        </div>
      </header>

      {/* Pricing Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-bold text-slate-900 mb-3">Simple, Transparent Pricing</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Choose the plan that fits your hiring or interview needs. Upgrade anytime as your volume grows.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* 3 Months Basic */}
            <div className="relative group bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-200 hover:-translate-y-1">
              <div className="p-6 flex flex-col h-full">
                <div className="mb-2">
                  <h3 className="text-lg font-semibold text-slate-900">3 Months Basic</h3>
                  <p className="text-sm text-slate-500">For trying secure AI interviews</p>
                </div>
                <div className="mt-4 mb-6">
                  <span className="text-3xl font-bold text-slate-900">₹499</span>
                  <span className="text-sm text-slate-500 ml-1">/ 3 months</span>
                </div>
                <ul className="space-y-2 text-sm text-slate-600 flex-1">
                  <li>• 3 AI Interview Sessions</li>
                  <li>• Basic Monitoring (face + tab switch)</li>
                  <li>• Email Report Only</li>
                </ul>
                <Button
                  className="mt-6 w-full bg-slate-900 text-white hover:bg-slate-800"
                  onClick={() => handleChoosePlan({
                    planName: 'Basic',
                    label: '3 Months Basic',
                    amount: 499,
                    validityDays: 90,
                  })}
                >
                  Choose Plan
                </Button>
              </div>
            </div>

            {/* 6 Months Standard (Recommended) */}
            <div className="relative group bg-gradient-to-b from-purple-600 to-teal-600 text-white rounded-2xl shadow-2xl transform hover:-translate-y-2 transition-all duration-200 border border-purple-500/40">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-white text-purple-700 shadow-md">
                  Recommended
                </span>
              </div>
              <div className="p-6 pt-8 flex flex-col h-full">
                <div className="mb-2">
                  <h3 className="text-lg font-semibold">6 Months Standard</h3>
                  <p className="text-sm text-purple-100">Best for active hiring pipelines</p>
                </div>
                <div className="mt-4 mb-6">
                  <span className="text-3xl font-bold">₹899</span>
                  <span className="text-sm text-purple-100 ml-1">/ 6 months</span>
                </div>
                <ul className="space-y-2 text-sm text-purple-50 flex-1">
                  <li>• 10 AI Interview Sessions</li>
                  <li>• Full Monitoring (face + gaze + head + tab switch)</li>
                  <li>• Priority Report</li>
                  <li>• Email + Dashboard Results</li>
                </ul>
                <Button
                  className="mt-6 w-full bg-white text-purple-700 hover:bg-purple-50"
                  onClick={() => handleChoosePlan({
                    planName: 'Standard',
                    label: '6 Months Standard',
                    amount: 899,
                    validityDays: 180,
                  })}
                >
                  Choose Plan
                </Button>
              </div>
            </div>

            {/* 1 Year Premium */}
            <div className="relative group bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-200 hover:-translate-y-1">
              <div className="p-6 flex flex-col h-full">
                <div className="mb-2">
                  <h3 className="text-lg font-semibold text-slate-900">1 Year Premium</h3>
                  <p className="text-sm text-slate-500">For teams standardizing on SecuHire</p>
                </div>
                <div className="mt-4 mb-6">
                  <span className="text-3xl font-bold text-slate-900">₹1499</span>
                  <span className="text-sm text-slate-500 ml-1">/ year</span>
                </div>
                <ul className="space-y-2 text-sm text-slate-600 flex-1">
                  <li>• Unlimited Sessions</li>
                  <li>• Full Monitoring Suite</li>
                  <li>• Voice Analysis</li>
                  <li>• Priority Support</li>
                  <li>• Admin Level Dashboard Access</li>
                </ul>
                <Button
                  className="mt-6 w-full bg-slate-900 text-white hover:bg-slate-800"
                  onClick={() => handleChoosePlan({
                    planName: 'Premium',
                    label: '1 Year Premium',
                    amount: 1499,
                    validityDays: 365,
                  })}
                >
                  Choose Plan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('secuhire_token'));
  const [userRole, setUserRole] = useState(localStorage.getItem('user_role'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
    setLoading(false);
  }, [token]);

  const login = (userData, userToken, role, companyData = null) => {
    console.log('Login called with:', { userData, userToken, role, companyData });
    setUser(userData);
    setCompany(companyData);
    setToken(userToken);
    setUserRole(role);
    localStorage.setItem('secuhire_token', userToken);
    localStorage.setItem('user_role', role);
    if (companyData) {
      localStorage.setItem('company_data', JSON.stringify(companyData));
    }
    axios.defaults.headers.common['Authorization'] = `Bearer ${userToken}`;
  };

  const logout = () => {
    setUser(null);
    setCompany(null);
    setToken(null);
    setUserRole(null);
    localStorage.removeItem('secuhire_token');
    localStorage.removeItem('user_role');
    localStorage.removeItem('company_data');
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, company, token, userRole, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Landing Page for SecuHire with Dual Options
const LandingPage = () => {
  const { user, userRole, token, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50">
      {/* Header */}
      <header className="px-6 py-4 border-b border-purple-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Shield className="w-8 h-8 text-purple-600" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-pulse"></div>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-teal-600 to-orange-500 bg-clip-text text-transparent">SecuHire</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="text-slate-600 hover:text-purple-600 hover:bg-purple-50">Features</Button>
            <Button
              variant="ghost"
              className="text-slate-600 hover:text-teal-600 hover:bg-teal-50"
              onClick={() => { window.location.href = '/pricing'; }}
            >
              Pricing
            </Button>
            {token && userRole === 'candidate' ? (
              <>
                <span className="text-slate-700 font-medium">{user?.full_name || user?.email || 'Candidate'}</span>
                <Button
                  variant="ghost"
                  className="text-slate-700 hover:text-red-600"
                  title="Logout"
                  aria-label="Logout"
                  onClick={() => { logout(); window.location.href = '/'; }}
                >
                  <LogOut className="w-5 h-5" />
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" className="border-purple-300 text-purple-700 hover:bg-purple-50" onClick={() => window.location.href = '/auth?type=recruiter'}>Recruiter Login</Button>
                <Button variant="outline" className="border-teal-300 text-teal-700 hover:bg-teal-50" onClick={() => window.location.href = '/auth?type=candidate'}>Candidate Login</Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div>
                <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-100 to-teal-100 text-purple-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
                  <Zap className="w-4 h-4" />
                  <span>AI-Powered Secure Hiring Platform</span>
                </div>
                <h2 className="text-5xl font-bold text-slate-800 leading-tight mb-6">
                  Secure & Intelligent
                  <span className="bg-gradient-to-r from-purple-600 via-teal-600 to-orange-500 bg-clip-text text-transparent block">Hiring Platform</span>
                </h2>
                <p className="text-xl text-slate-600 leading-relaxed">
                  Connect talented candidates with innovative companies through our secure platform. 
                  Advanced verification, AI-powered matching, and streamlined hiring process.
                </p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <Button size="lg" className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white px-8 py-4 shadow-xl" onClick={() => window.location.href = '/auth?type=recruiter'}>
                  <Building2 className="w-5 h-5 mr-2" />
                  For Recruiters
                </Button>
                <Button size="lg" className="bg-gradient-to-r from-teal-600 to-orange-500 hover:from-teal-700 hover:to-orange-600 text-white px-8 py-4 shadow-xl" onClick={() => window.location.href = '/auth?type=candidate'}>
                  <User className="w-5 h-5 mr-2" />
                  For Candidates
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Shield className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm text-slate-600 font-medium">Secure Verification</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-teal-500 to-teal-600 rounded-lg flex items-center justify-center">
                    <Brain className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm text-slate-600 font-medium">AI-Powered Matching</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-pink-500 rounded-lg flex items-center justify-center">
                    <Target className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm text-slate-600 font-medium">Smart Pipeline</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-teal-600/20 rounded-3xl blur-3xl"></div>
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?crop=entropy&cs=srgb&fm=jpg&q=85"
                alt="Professional Team Collaboration"
                className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover border border-white/20"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Dual Features Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-slate-50 to-purple-50/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-slate-800 mb-4">For Every Step of Your Career Journey</h3>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Whether you're hiring talent or seeking opportunities, SecuHire provides the tools you need
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* For Recruiters */}
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-2xl font-bold text-slate-800 mb-2">For Recruiters</h4>
                <p className="text-slate-600">Complete ATS & CRM solution for modern hiring teams</p>
              </div>

              <div className="space-y-4">
                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Briefcase className="w-6 h-6 text-purple-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Smart Job Management</h5>
                        <p className="text-sm text-slate-600">AI-assisted job creation and publishing</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Users className="w-6 h-6 text-purple-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Candidate Database</h5>
                        <p className="text-sm text-slate-600">Verified profiles with skill matching</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <BarChart3 className="w-6 h-6 text-purple-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Analytics Dashboard</h5>
                        <p className="text-sm text-slate-600">Hiring metrics and pipeline insights</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* For Candidates */}
            <div className="space-y-6">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-2xl font-bold text-slate-800 mb-2">For Candidates</h4>
                <p className="text-slate-600">Secure platform to find and apply for dream jobs</p>
              </div>

              <div className="space-y-4">
                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Search className="w-6 h-6 text-teal-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Job Discovery</h5>
                        <p className="text-sm text-slate-600">Find relevant opportunities with smart matching</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Verified className="w-6 h-6 text-teal-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Secure Verification</h5>
                        <p className="text-sm text-slate-600">Email and phone verification for authenticity</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white group hover:shadow-xl transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Video className="w-6 h-6 text-teal-600" />
                      <div>
                        <h5 className="font-semibold text-slate-800">Secure Interviews</h5>
                        <p className="text-sm text-slate-600">AI-monitored interviews with fraud detection</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-purple-600 via-teal-600 to-orange-500 rounded-3xl p-12 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-black/20 rounded-3xl"></div>
            <div className="relative">
              <h3 className="text-4xl font-bold mb-6">Ready to Transform Your Career?</h3>
              <p className="text-xl text-purple-100 mb-8">
                Join thousands of professionals and companies using SecuHire for secure, efficient hiring.
              </p>
              <div className="flex justify-center space-x-4">
                <Button size="lg" className="bg-white text-purple-600 hover:bg-purple-50 px-8 py-4 text-lg font-semibold shadow-xl" onClick={() => window.location.href = '/auth?type=recruiter'}>
                  Start Hiring
                </Button>
                <Button size="lg" className="bg-purple-800 text-white hover:bg-purple-900 px-8 py-4 text-lg font-semibold shadow-xl" onClick={() => window.location.href = '/auth?type=candidate'}>
                  Find Jobs
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

// Dual Auth Component for Both Recruiters and Candidates
const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const navigate = useNavigate();
  const [userType, setUserType] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('type') || 'recruiter';
  });
  const { token: appToken, userRole } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    full_name: '',
    company_name: '',
    company_domain: '',
    company_size: '',
    industry: '',
    phone: '',
    location: '',
    current_title: '',
    current_company: '',
    experience_years: '',
    education: '',
    skills: '',
    expected_salary: '',
    linkedin_url: '',
    portfolio_url: '',
    bio: ''
  });
  const [loading, setLoading] = useState(false);
  const [verificationStep, setVerificationStep] = useState(null);
  const [verificationCodes, setVerificationCodes] = useState({});
  const [verificationInputs, setVerificationInputs] = useState({
    emailCode: '',
    phoneOtp: ''
  });
  const { login } = useAuth();
  const [syncing, setSyncing] = useState(false);
  const [synced, setSynced] = useState(false);
  const [showAccountOtp, setShowAccountOtp] = useState(false);
  const [accountOtpCode, setAccountOtpCode] = useState("");
  const [otpEmail, setOtpEmail] = useState("");
  const [otpSending, setOtpSending] = useState(false);

  // Clerk flow removed; native email/password + OTP used for both roles

  // no set-password flow in rollback

  // no password banner in rollback

  const handleVerifyAccountOtp = async (e) => {
    e?.preventDefault?.();
    if (!otpEmail || !accountOtpCode) return;
    setLoading(true);
    try {
      const resp = await axios.post(`${API}/candidates/verify-account-otp`, { email: otpEmail, code: accountOtpCode });
      const data = resp.data;
      login(data.user, data.token, 'candidate', null);
      setSynced(true);
      setShowAccountOtp(false);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      alert(err.response?.data?.detail || 'Invalid or expired code');
    } finally {
      setLoading(false);
    }
  };

  const handleResendAccountOtp = async () => {
    if (!otpEmail) return;
    try {
      setOtpSending(true);
      await axios.post(`${API}/candidates/request-account-otp`, null, { params: { email: otpEmail } });
      alert('OTP sent to your email');
    } catch (err) {
      alert(err.response?.data?.detail || 'Failed to send OTP');
    } finally {
      setOtpSending(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = isLogin ? 
        (userType === 'recruiter' ? '/recruiters/auth/login' : '/candidates/auth/login') :
        (userType === 'recruiter' ? '/recruiters/auth/register' : '/candidates/auth/register');
      
      let payload;
      if (isLogin) {
        payload = { email: formData.email, password: formData.password };
      } else {
        if (userType === 'recruiter') {
          payload = {
            email: formData.email,
            password: formData.password,
            full_name: formData.full_name,
            company_name: formData.company_name,
            company_domain: formData.company_domain,
            company_size: formData.company_size,
            industry: formData.industry
          };
        } else {
          payload = {
            email: formData.email,
            password: formData.password,
            full_name: formData.full_name,
            phone: formData.phone,
            location: formData.location,
            current_title: formData.current_title,
            current_company: formData.current_company,
            experience_years: parseInt(formData.experience_years) || 0,
            education: formData.education,
            skills: formData.skills.split(',').map(s => s.trim()).filter(s => s),
            expected_salary: formData.expected_salary ? parseInt(formData.expected_salary) : null,
            linkedin_url: formData.linkedin_url,
            portfolio_url: formData.portfolio_url,
            bio: formData.bio
          };
        }
      }

      console.log('Submitting to:', `${API}${endpoint}`, payload);
      const response = await axios.post(`${API}${endpoint}`, payload);
      console.log('Auth response:', response.data);
      
      if (response.data.verification_required && userType === 'candidate' && !isLogin) {
        // Handle verification flow for new candidates
        setVerificationCodes({
          email: response.data.email_verification_code,
          phone: response.data.phone_otp,
          userId: response.data.user.id
        });
        setVerificationStep('verify');
        login(response.data.user, response.data.token, response.data.role, response.data.company);
      } else {
        // Direct login
        login(response.data.user, response.data.token, response.data.role, response.data.company);
        if (response.data.role === 'recruiter') {
          navigate('/recruiter/dashboard', { replace: true });
        } else {
          navigate('/candidate/dashboard', { replace: true });
        }
      }
    } catch (error) {
      console.error('Auth error:', error);
      alert(error.response?.data?.detail || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  // Download/view candidate resume for this application
  const viewResume = async () => {
    return downloadResume(candidate.id, candidate.full_name);
  };

  const handleVerification = async (type) => {
    try {
      setLoading(true);
      const endpoint = type === 'email' ? '/candidates/verify-email' : '/candidates/verify-phone';
      const code = type === 'email' ? verificationInputs.emailCode : verificationInputs.phoneOtp;
      
      await axios.post(`${API}${endpoint}`, {
        user_id: verificationCodes.userId,
        [type === 'email' ? 'verification_code' : 'otp_code']: code
      });
      
      alert(`${type === 'email' ? 'Email' : 'Phone'} verified successfully!`);
      
      // Check if both are verified, then proceed
      if (type === 'email') {
        setVerificationInputs({...verificationInputs, emailVerified: true});
      } else {
        setVerificationInputs({...verificationInputs, phoneVerified: true});
      }
      
    } catch (error) {
      alert(error.response?.data?.detail || `${type} verification failed`);
    } finally {
      setLoading(false);
    }
  };

  if (verificationStep === 'verify') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50 flex items-center justify-center p-6">
        <Card className="w-full max-w-md shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader className="text-center pb-6">
            <div className="flex justify-center mb-4">
              <Verified className="w-12 h-12 text-teal-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-800">
              Verify Your Account
            </CardTitle>
            <CardDescription className="text-slate-600">
              Complete verification to secure your account
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Email Verification */}
            <div className="space-y-3">
              <Label className="text-slate-700 font-medium">Email Verification</Label>
              <div className="flex space-x-2">
                <Input
                  placeholder="Enter email code"
                  value={verificationInputs.emailCode}
                  onChange={(e) => setVerificationInputs({...verificationInputs, emailCode: e.target.value})}
                  className="flex-1"
                />
                <Button 
                  onClick={() => handleVerification('email')}
                  disabled={loading || !verificationInputs.emailCode}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  Verify
                </Button>
              </div>
              <p className="text-xs text-slate-500">Demo code: {verificationCodes.email}</p>
            </div>

            {/* Phone Verification */}
            <div className="space-y-3">
              <Label className="text-slate-700 font-medium">Phone Verification</Label>
              <div className="flex space-x-2">
                <Input
                  placeholder="Enter OTP"
                  value={verificationInputs.phoneOtp}
                  onChange={(e) => setVerificationInputs({...verificationInputs, phoneOtp: e.target.value})}
                  className="flex-1"
                />
                <Button 
                  onClick={() => handleVerification('phone')}
                  disabled={loading || !verificationInputs.phoneOtp}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  Verify
                </Button>
              </div>
              <p className="text-xs text-slate-500">Demo OTP: {verificationCodes.phone}</p>
            </div>

            <Button 
              onClick={() => setVerificationStep(null)}
              className="w-full bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700"
            >
              Continue to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // no set-password flow in native auth mode

  // Clerk candidate SignUp UI removed; fall through to native forms

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="relative">
              {userType === 'recruiter' ? (
                <Building2 className="w-12 h-12 text-purple-600" />
              ) : (
                <User className="w-12 h-12 text-teal-600" />
              )}
            </div>
          </div>
          
          {/* User Type Selector */}
          <div className="flex justify-center space-x-2 mb-6">
            <Button
              variant={userType === 'recruiter' ? 'default' : 'outline'}
              className={userType === 'recruiter' ? 'bg-purple-600 hover:bg-purple-700' : 'border-purple-300 text-purple-700'}
              onClick={() => setUserType('recruiter')}
            >
              <Building2 className="w-4 h-4 mr-2" />
              Recruiter
            </Button>
            <Button
              variant={userType === 'candidate' ? 'default' : 'outline'}
              className={userType === 'candidate' ? 'bg-teal-600 hover:bg-teal-700' : 'border-teal-300 text-teal-700'}
              onClick={() => setUserType('candidate')}
            >
              <User className="w-4 h-4 mr-2" />
              Candidate
            </Button>
          </div>

          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-teal-600 bg-clip-text text-transparent">
            {isLogin ? 'Welcome Back to SecuHire' : `Join SecuHire as ${userType === 'recruiter' ? 'a Recruiter' : 'a Candidate'}`}
          </CardTitle>
          <CardDescription className="text-slate-600">
            {isLogin ? 
              `Sign in to your ${userType} dashboard` : 
              `Create your ${userType} account and get started`
            }
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Common Fields */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" className="text-slate-700 font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                  className="mt-1 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>

              <div>
                <Label htmlFor="password" className="text-slate-700 font-medium">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  required
                  className="mt-1 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                />
              </div>
            </div>

            {!isLogin && (
              <>
                <div>
                  <Label htmlFor="full_name" className="text-slate-700 font-medium">Full Name</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                    required
                    className="mt-1 border-slate-300 focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>

                {userType === 'recruiter' ? (
                  // Recruiter-specific fields
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="company_name" className="text-slate-700 font-medium">Company Name</Label>
                        <Input
                          id="company_name"
                          value={formData.company_name}
                          onChange={(e) => setFormData({...formData, company_name: e.target.value})}
                          required
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="company_domain" className="text-slate-700 font-medium">Company Domain</Label>
                        <Input
                          id="company_domain"
                          value={formData.company_domain}
                          onChange={(e) => setFormData({...formData, company_domain: e.target.value})}
                          required
                          className="mt-1"
                          placeholder="company.com"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="company_size" className="text-slate-700 font-medium">Company Size</Label>
                        <Select onValueChange={(value) => setFormData({...formData, company_size: value})}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select company size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1-10">1-10 employees</SelectItem>
                            <SelectItem value="11-50">11-50 employees</SelectItem>
                            <SelectItem value="51-200">51-200 employees</SelectItem>
                            <SelectItem value="200+">200+ employees</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="industry" className="text-slate-700 font-medium">Industry</Label>
                        <Select onValueChange={(value) => setFormData({...formData, industry: value})}>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Select industry" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Technology">Technology</SelectItem>
                            <SelectItem value="Healthcare">Healthcare</SelectItem>
                            <SelectItem value="Finance">Finance</SelectItem>
                            <SelectItem value="Education">Education</SelectItem>
                            <SelectItem value="Retail">Retail</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  // Candidate-specific fields
                  <>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone" className="text-slate-700 font-medium">Phone Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                          required
                          className="mt-1"
                          placeholder="+1234567890"
                        />
                      </div>

                      <div>
                        <Label htmlFor="location" className="text-slate-700 font-medium">Location</Label>
                        <Input
                          id="location"
                          value={formData.location}
                          onChange={(e) => setFormData({...formData, location: e.target.value})}
                          required
                          className="mt-1"
                          placeholder="City, State"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="current_title" className="text-slate-700 font-medium">Current Job Title</Label>
                        <Input
                          id="current_title"
                          value={formData.current_title}
                          onChange={(e) => setFormData({...formData, current_title: e.target.value})}
                          required
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="current_company" className="text-slate-700 font-medium">Current Company</Label>
                        <Input
                          id="current_company"
                          value={formData.current_company}
                          onChange={(e) => setFormData({...formData, current_company: e.target.value})}
                          required
                          className="mt-1"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="experience_years" className="text-slate-700 font-medium">Years of Experience</Label>
                        <Input
                          id="experience_years"
                          type="number"
                          value={formData.experience_years}
                          onChange={(e) => setFormData({...formData, experience_years: e.target.value})}
                          required
                          className="mt-1"
                          min="0"
                        />
                      </div>

                      <div>
                        <Label htmlFor="education" className="text-slate-700 font-medium">Education</Label>
                        <Input
                          id="education"
                          value={formData.education}
                          onChange={(e) => setFormData({...formData, education: e.target.value})}
                          required
                          className="mt-1"
                          placeholder="BS Computer Science"
                        />
                      </div>

                      <div>
                        <Label htmlFor="expected_salary" className="text-slate-700 font-medium">Expected Salary</Label>
                        <Input
                          id="expected_salary"
                          type="number"
                          value={formData.expected_salary}
                          onChange={(e) => setFormData({...formData, expected_salary: e.target.value})}
                          className="mt-1"
                          placeholder="120000"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="skills" className="text-slate-700 font-medium">Skills (comma-separated)</Label>
                      <Input
                        id="skills"
                        value={formData.skills}
                        onChange={(e) => setFormData({...formData, skills: e.target.value})}
                        required
                        className="mt-1"
                        placeholder="React, Python, JavaScript, MongoDB"
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="linkedin_url" className="text-slate-700 font-medium">LinkedIn URL (Optional)</Label>
                        <Input
                          id="linkedin_url"
                          type="url"
                          value={formData.linkedin_url}
                          onChange={(e) => setFormData({...formData, linkedin_url: e.target.value})}
                          className="mt-1"
                          placeholder="https://linkedin.com/in/yourprofile"
                        />
                      </div>

                      <div>
                        <Label htmlFor="portfolio_url" className="text-slate-700 font-medium">Portfolio URL (Optional)</Label>
                        <Input
                          id="portfolio_url"
                          type="url"
                          value={formData.portfolio_url}
                          onChange={(e) => setFormData({...formData, portfolio_url: e.target.value})}
                          className="mt-1"
                          placeholder="https://yourportfolio.com"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="bio" className="text-slate-700 font-medium">Professional Bio (Optional)</Label>
                      <Textarea
                        id="bio"
                        value={formData.bio}
                        onChange={(e) => setFormData({...formData, bio: e.target.value})}
                        className="mt-1"
                        rows={3}
                        placeholder="Tell us about your professional background and goals..."
                      />
                    </div>
                  </>
                )}
              </>
            )}

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg" 
              disabled={loading}
            >
              {loading ? 'Loading...' : (isLogin ? 'Sign In' : 'Create Account')}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-purple-600 hover:text-teal-600 font-medium transition-colors"
            >
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Candidate Dashboard Component
const CandidateDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('jobs');
  const [jobs, setJobs] = useState([]);
  const [myApplications, setMyApplications] = useState([]);
  const [myInterviews, setMyInterviews] = useState([]);

  const [searchFilters, setSearchFilters] = useState({
    search: '',
    location: '',
    job_type: '',
    experience_level: ''
  });
  const [selectedInterview, setSelectedInterview] = useState(null);
  const [showSecureInterview, setShowSecureInterview] = useState(false);
  const [interviewData, setInterviewData] = useState(null);
  const { user, logout } = useAuth();

  useEffect(() => {
    fetchCandidateData();
  }, []);

  const fetchCandidateData = async () => {

    try {
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };

      const [jobsRes, applicationsRes, interviewsRes] = await Promise.all([
        axios.get(`${API}/candidates/jobs`, { headers }),
        axios.get(`${API}/candidates/my-applications`, { headers }),
        axios.get(`${API}/candidates/interviews`, { headers })
      ]);

      setJobs(jobsRes.data);
      setMyApplications(applicationsRes.data);
      setMyInterviews(interviewsRes.data);
    } catch (error) {
      console.error('Failed to fetch candidate data:', error);
    }
  };

  const startInterviewImmediately = async (interview) => {
    try {
      // Start the interview on the backend
      await axios.post(`${API}/interviews/${interview.id}/start`, {}, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
          'Content-Type': 'application/json'
        }
      });

      // Prepare headers for follow-up requests
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };

      // Fetch company/job details only if IDs are present; continue even if they fail
      let companyData = null;
      let jobData = null;
      try {
        if (interview?.company_id) {
          const companyRes = await axios.get(`${API}/companies/${interview.company_id}`, { headers });
          companyData = companyRes.data;
        }
      } catch (e) {
        console.warn('Company fetch skipped/failed:', e?.response?.status, e?.message);
      }
      try {
        if (interview?.job_id) {
          const jobRes = await axios.get(`${API}/jobs/${interview.job_id}`, { headers });
          jobData = jobRes.data;
        }
      } catch (e) {
        console.warn('Job fetch skipped/failed:', e?.response?.status, e?.message);
      }

      setInterviewData({
        interview: { ...interview, status: 'in_progress' },
        company: companyData || {},
        job: jobData || {}
      });
      setShowSecureInterview(true);
    } catch (error) {
      console.error('Failed to start interview:', error);
      const msg = error?.response?.data?.detail || error?.message || 'Could not start the interview automatically. Please try again from the Interviews tab.';
      alert(msg);
    }
  };

  const applyForJob = async (jobId, coverLetter) => {
    try {
      const response = await axios.post(`${API}/candidates/applications`, {
        job_id: jobId,
        cover_letter: coverLetter
      }, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      const data = response.data;
      
      // Check if interview was automatically scheduled
      if (data.interview && data.can_start_immediately) {
        const interviewDate = new Date(data.interview.scheduled_date).toLocaleString();
        const shouldStartNow = confirm(
          [
            'Application submitted successfully!',
            '',
            'Interview is ready now:',
            `- Date: ${interviewDate}`,
            `- Duration: ${data.interview.duration_minutes} minutes`,
            `- Type: ${data.interview.interview_type}`,
            `- Meeting: ${data.interview.meeting_link}`,
            '',
            'Would you like to start the interview now?'
          ].join('\n')
        );

        if (shouldStartNow) {
          // Start the interview immediately
          await startInterviewImmediately({
            ...data.interview,
            job_id: data.application?.job_id || data.interview?.job_id,
            company_id: data.application?.company_id || data.interview?.company_id
          });
        } else {
          alert('Interview is ready. You can start it anytime from the "Interviews" tab.');
        }
      } else if (data.interview) {
        const interviewDate = new Date(data.interview.scheduled_date).toLocaleString();
        alert([
          'Application submitted successfully!',
          '',
          'Interview scheduled:',
          `- Date: ${interviewDate}`,
          `- Duration: ${data.interview.duration_minutes} minutes`,
          `- Type: ${data.interview.interview_type}`,
          '',
          'You can view interview details in the "Interviews" tab.'
        ].join('\n'));
      } else {
        alert('Application submitted successfully!\n\nAn interview will be scheduled by the recruiter and you will be notified.');
      }
      
      fetchCandidateData(); // Refresh data
    } catch (error) {
      console.error('Application error:', error);
      const errorMessage = error.response?.data?.detail || 
                          error.response?.data?.message || 
                          error.message || 
                          'Application failed';
      alert(errorMessage);
    }
  };

  const searchJobs = async () => {
    try {
      const params = new URLSearchParams();
      Object.entries(searchFilters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };
      
      const response = await axios.get(`${API}/candidates/jobs?${params}`, { headers });
      setJobs(response.data);
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  const startSecureInterview = async (interview) => {
    try {
      // Immediately open the interview session with placeholders (do not block on network)
      setInterviewData({
        interview,
        company: { name: 'Company', industry: '' },
        job: { title: 'Interview', description: '' }
      });
      setShowSecureInterview(true);

      // In background: start interview on backend (ensures session + permissions ready)
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };
      try {
        await axios.post(`${API}/interviews/${interview.id}/start`, {}, { headers });
      } catch (e) {
        console.warn('Start interview warning:', e.response?.status, e.response?.data);
      }

      // In background: try to fetch company and job details; ignore errors (CORS etc.)
      try {
        const [companyRes, jobRes] = await Promise.all([
          axios.get(`${API}/companies/${interview.company_id}`, { headers }),
          axios.get(`${API}/jobs/${interview.job_id}`, { headers })
        ]);
        setInterviewData(prev => ({
          interview: prev?.interview || interview,
          company: companyRes.data || prev?.company,
          job: jobRes.data || prev?.job
        }));
      } catch (bgErr) {
        // Keep session running with placeholder details
        console.warn('Background details fetch failed (non-blocking):', bgErr?.response?.status);
      }
    } catch (error) {
      console.error('Failed to start interview flow:', error);
      // Ensure UI still opens
      setInterviewData({
        interview,
        company: { name: 'Company', industry: '' },
        job: { title: 'Interview', description: '' }
      });
      setShowSecureInterview(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-teal-50/20">
      {/* Header */}
      <header className="bg-white border-b border-teal-200 px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Shield className="w-8 h-8 text-teal-600" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-teal-600 via-purple-600 to-orange-500 bg-clip-text text-transparent">SecuHire</h1>
              <p className="text-sm text-slate-600">Candidate Portal</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {user?.is_email_verified ? (
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Email Verified
                </Badge>
              ) : (
                <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Email Pending
                </Badge>
              )}
              {user?.is_phone_verified ? (
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Phone Verified
                </Badge>
              ) : (
                <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Phone Pending
                </Badge>
              )}
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-600">Welcome back,</p>
              <p className="font-semibold text-slate-800">{user?.full_name}</p>
            </div>
            <Button
              variant="ghost"
              className="text-slate-700 hover:text-red-600"
              title="Logout"
              aria-label="Logout"
              onClick={() => { logout(); navigate('/auth', { replace: true }); }}
            >
              <LogOut className="w-5 h-5" />
            </Button>

          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {/* rollback: no set password banner */}
          {/* Main Navigation Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid grid-cols-4 w-full max-w-2xl bg-white border border-teal-200 shadow-sm">
              <TabsTrigger value="jobs" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-teal-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">Browse Jobs</TabsTrigger>
              <TabsTrigger value="applications" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-teal-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">My Applications</TabsTrigger>
              <TabsTrigger value="interviews" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-teal-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">Interviews</TabsTrigger>
              <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-teal-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">Profile</TabsTrigger>
            </TabsList>

            {/* Job Browsing */}
            <TabsContent value="jobs" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Available Jobs</h2>
                <Badge className="bg-teal-100 text-teal-800 border-teal-200">
                  {jobs.length} opportunities
                </Badge>
              </div>

              {/* Search and Filters */}
              <Card className="border-0 shadow-lg bg-white">
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <Label className="text-sm font-medium text-slate-700">Search</Label>
                      <div className="relative mt-1">
                        <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                        <Input
                          placeholder="Job title, skills..."
                          className="pl-10"
                          value={searchFilters.search}
                          onChange={(e) => setSearchFilters({...searchFilters, search: e.target.value})}
                        />
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium text-slate-700">Location</Label>
                      <Input
                        placeholder="City, State"
                        className="mt-1"
                        value={searchFilters.location}
                        onChange={(e) => setSearchFilters({...searchFilters, location: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label className="text-sm font-medium text-slate-700">Job Type</Label>
                      <Select value={searchFilters.job_type} onValueChange={(value) => setSearchFilters({...searchFilters, job_type: value})}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="All types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All types</SelectItem>
                          <SelectItem value="Full-time">Full-time</SelectItem>
                          <SelectItem value="Part-time">Part-time</SelectItem>
                          <SelectItem value="Contract">Contract</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-sm font-medium text-slate-700">Experience Level</Label>
                      <Select value={searchFilters.experience_level} onValueChange={(value) => setSearchFilters({...searchFilters, experience_level: value})}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="All levels" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All levels</SelectItem>
                          <SelectItem value="Entry">Entry Level</SelectItem>
                          <SelectItem value="Mid">Mid Level</SelectItem>
                          <SelectItem value="Senior">Senior Level</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button onClick={searchJobs} className="bg-gradient-to-r from-teal-600 to-purple-600 hover:from-teal-700 hover:to-purple-700 text-white">
                    <Search className="w-4 h-4 mr-2" />
                    Search Jobs
                  </Button>
                </CardContent>
              </Card>

              {/* Job Listings */}
              <div className="grid gap-6">
                {jobs.length > 0 ? jobs.map((item, index) => (
                  <CandidateJobCard key={index} jobData={item} onApply={applyForJob} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-teal-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <Search className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No jobs found</h3>
                      <p className="text-slate-500 mb-4">Try adjusting your search filters to find more opportunities</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>


            {/* My Applications */}
            <TabsContent value="applications" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">My Applications</h2>
                <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                  {myApplications.length} applications
                </Badge>
              </div>

              <div className="grid gap-6">
                {myApplications.length > 0 ? myApplications.map((item, index) => (
                  <CandidateApplicationCard key={index} applicationData={item} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <FileText className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No applications yet</h3>
                      <p className="text-slate-500 mb-4">Start applying to jobs to track your applications here</p>
                      <Button onClick={() => setActiveTab('jobs')} className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700">
                        Browse Jobs
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Interviews */}
            <TabsContent value="interviews" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">My Interviews</h2>
                <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                  {myInterviews.length} scheduled
                </Badge>
              </div>

              <div className="grid gap-6">
                {myInterviews.length > 0 ? myInterviews.map((item, index) => (
                  <InterviewCard key={index} interviewData={item} onStartSecureInterview={startSecureInterview} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <Calendar className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No interviews scheduled</h3>
                      <p className="text-slate-500 mb-4">Interviews will appear here once companies schedule them</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Profile */}
            <TabsContent value="profile" className="space-y-6">
              <CandidateProfile user={user} />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Secure Interview Modal */}
      {showSecureInterview && interviewData && (
        <SecureInterviewSession 
          interview={interviewData.interview}
          company={interviewData.company}
          job={interviewData.job}
          onEnd={() => {
            setShowSecureInterview(false);
            setInterviewData(null);
            fetchCandidateData(); // Refresh data
          }}
          onClose={() => {
            setShowSecureInterview(false);
            setInterviewData(null);
          }} 
        />
      )}
    </div>
  );
};

// Candidate Job Card Component
const CandidateJobCard = ({ jobData, onApply }) => {
  const [showApplyDialog, setShowApplyDialog] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const { job, company, has_applied } = jobData;

  const handleApply = () => {
    onApply(job.id, coverLetter);
    setShowApplyDialog(false);
    setCoverLetter('');
  };

  const getSalaryRange = () => {
    if (job.salary_min && job.salary_max) {
      return `$${job.salary_min.toLocaleString()} - $${job.salary_max.toLocaleString()}`;
    }
    return 'Salary not specified';
  };

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <h3 className="text-xl font-semibold text-slate-800 group-hover:text-teal-700 transition-colors">{job.title}</h3>
              {company && (
                <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
                  {company.name}
                </Badge>
              )}
            </div>
            
            <div className="flex items-center space-x-4 text-sm text-slate-600 mb-3">
              <div className="flex items-center space-x-1">
                <MapPin className="w-4 h-4" />
                <span>{job.location}</span>
              </div>
              <div className="flex items-center space-x-1">
                <DollarSign className="w-4 h-4" />
                <span>{getSalaryRange()}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Briefcase className="w-4 h-4" />
                <span>{job.job_type}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4" />
                <span>{job.experience_level}</span>
              </div>
            </div>
          </div>

          {has_applied ? (
            <Badge className="bg-green-100 text-green-800 border-green-200">
              <CheckCircle className="w-3 h-3 mr-1" />
              Applied
            </Badge>
          ) : (
            <Badge className="bg-blue-100 text-blue-800 border-blue-200">
              Open
            </Badge>
          )}
        </div>

        <p className="text-slate-600 mb-4 line-clamp-3">{job.description}</p>

        <div className="mb-4">
          <h4 className="font-medium text-slate-800 mb-2">Required Skills:</h4>
          <div className="flex flex-wrap gap-2">
            {job.skills?.map((skill, index) => (
              <Badge key={index} variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                {skill}
              </Badge>
            ))}
          </div>
        </div>

        {!has_applied && (
          <Dialog open={showApplyDialog} onOpenChange={setShowApplyDialog}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-teal-600 to-purple-600 hover:from-teal-700 hover:to-purple-700 text-white w-full">
                <Send className="w-4 h-4 mr-2" />
                Apply Now
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Apply for {job.title}</DialogTitle>
                <DialogDescription>
                  Submit your application to {company?.name || 'this company'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="cover-letter">Cover Letter</Label>
                  <Textarea
                    id="cover-letter"
                    placeholder="Write a compelling cover letter for this position..."
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    rows={6}
                    className="mt-1"
                  />
                </div>
                <div className="flex space-x-3">
                  <Button onClick={handleApply} className="bg-gradient-to-r from-teal-600 to-purple-600 hover:from-teal-700 hover:to-purple-700 flex-1">
                    Submit Application
                  </Button>
                  <Button variant="outline" onClick={() => setShowApplyDialog(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
};

// Candidate Application Card Component
const CandidateApplicationCard = ({ applicationData }) => {
  const { application, job, company } = applicationData;

  const getStageColor = (stage) => {
    switch (stage) {
      case 'new': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'screening': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'phone_screen': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'technical_interview': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'final_interview': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'offer': return 'bg-green-100 text-green-800 border-green-200';
      case 'hired': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatStage = (stage) => {
    return stage.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (!job || !company) return null;

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-800 group-hover:text-purple-700 transition-colors mb-1">
              {job.title}
            </h3>
            <p className="text-slate-600 mb-2">{company.name}</p>
            <p className="text-sm text-slate-500">
              Applied on {new Date(application.applied_date).toLocaleDateString()}
            </p>
          </div>
          
          <Badge className={`${getStageColor(application.stage)} border font-medium`}>
            {formatStage(application.stage)}
          </Badge>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-4 text-sm text-slate-600">
          <div className="flex items-center space-x-1">
            <MapPin className="w-4 h-4" />
            <span>{job.location}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Briefcase className="w-4 h-4" />
            <span>{job.job_type}</span>
          </div>
        </div>

        <div className="mb-4">
          <Label className="text-sm font-medium text-slate-700">Cover Letter:</Label>
          <p className="text-slate-600 text-sm mt-1 bg-slate-50 p-3 rounded-lg">
            {application.cover_letter}
          </p>
        </div>

        <div className="flex space-x-3">
          <Button variant="outline" size="sm" className="border-purple-300 text-purple-700 hover:bg-purple-50">
            <Eye className="w-4 h-4 mr-2" />
            View Details
          </Button>
          {application.stage === 'offer' && (
            <Button size="sm" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white">
              <CheckCircle className="w-4 h-4 mr-2" />
              Accept Offer
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Interview Card Component
const InterviewCard = ({ interviewData, onStartSecureInterview }) => {
  const [showSecureInterview, setShowSecureInterview] = useState(false);
  const { interview, application, job, company } = interviewData;

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'in_progress': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200';
      case 'no_show': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  };

  const isInterviewTime = () => {
    const now = new Date();
    const interviewTime = new Date(interview.scheduled_date);
    const timeDiff = interviewTime.getTime() - now.getTime();
    // Allow joining 10 minutes before scheduled time
    return timeDiff <= 10 * 60 * 1000 && timeDiff >= -interview.duration_minutes * 60 * 1000;
  };

  const timeUntilInterview = () => {
    const now = new Date();
    const interviewTime = new Date(interview.scheduled_date);
    const timeDiff = interviewTime.getTime() - now.getTime();
    
    if (timeDiff < 0) return 'Interview time has passed';
    
    const hours = Math.floor(timeDiff / (1000 * 60 * 60));
    const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 24) {
      const days = Math.floor(hours / 24);
      return `In ${days} day${days > 1 ? 's' : ''}`;
    } else if (hours > 0) {
      return `In ${hours}h ${minutes}m`;
    } else {
      return `In ${minutes} minute${minutes > 1 ? 's' : ''}`;
    }
  };

  const handleJoinInterview = () => {
    if (interview.status === 'scheduled') {
      setShowSecureInterview(true);
    }
  };

  const handleEndInterview = () => {
    setShowSecureInterview(false);
    // In production, update interview status
  };

  if (showSecureInterview) {
    return <SecureInterviewSession interview={interview} onEndInterview={handleEndInterview} />;
  }

  const { date, time } = formatDateTime(interview.scheduled_date);

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <h3 className="text-lg font-semibold text-slate-800 group-hover:text-orange-700 transition-colors">
                {interview.interview_type.charAt(0).toUpperCase() + interview.interview_type.slice(1)} Interview
              </h3>
              <Badge className={`${getStatusColor(interview.status)} border font-medium`}>
                {interview.status.replace('_', ' ').toUpperCase()}
              </Badge>
            </div>
            
            {job && (
              <h4 className="text-md font-medium text-slate-700 mb-1">{job.title}</h4>
            )}
            {company && (
              <p className="text-slate-600 mb-2">{company.name}</p>
            )}
          </div>
          
          <div className="text-right">
            <div className="text-sm text-slate-500 mb-1">
              {timeUntilInterview()}
            </div>
            {isInterviewTime() && interview.status === 'scheduled' && (
              <Badge className="bg-green-100 text-green-800 border-green-200 animate-pulse">
                <Video className="w-3 h-3 mr-1" />
                Ready to Join
              </Badge>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-4">
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4" />
            <span>{date}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <Clock className="w-4 h-4" />
            <span>{time}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-slate-600">
            <Timer className="w-4 h-4" />
            <span>{interview.duration_minutes} minutes</span>
          </div>
        </div>

        {/* SecuHire runs interviews in-app; hide any external meeting links */}

        <div className="flex space-x-3">
          {(interview.status === 'scheduled' || interview.status === 'in_progress') && (
            <Button 
              onClick={() => (onStartSecureInterview ? onStartSecureInterview(interview) : setShowSecureInterview(true))}
              className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white flex items-center space-x-2"
            >
              <Shield className="w-4 h-4" />
              <span>{interview.status === 'in_progress' ? 'Rejoin SecuHire Interview' : 'Start SecuHire Interview'}</span>
            </Button>
          )}

          <Button variant="outline" size="sm" className="border-slate-300 text-slate-700 hover:bg-slate-50">
            <Eye className="w-4 h-4 mr-2" />
            View Details
          </Button>
        </div>

        {(interview.status === 'scheduled' || interview.status === 'in_progress') && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center space-x-2 text-blue-800">
              <Shield className="w-4 h-4" />
              <span className="text-sm font-medium">Security Notice</span>
            </div>
            <p className="text-sm text-blue-700 mt-1">
              This interview will use advanced security monitoring including camera recording, screen monitoring, and tab switching prevention.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
// Recruiter Live Interview Monitoring Dashboard
const RecruiterInterviewMonitor = ({ interview, onClose }) => {
  const [monitoringData, setMonitoringData] = useState(null);
  const [securityViolations, setSecurityViolations] = useState([]);
  const [isLive, setIsLive] = useState(false);
  const [websocket, setWebsocket] = useState(null);
  const candidateVideoRef = useRef(null);
  const candidateScreenRef = useRef(null);

  useEffect(() => {
    fetchMonitoringData();
    initializeRecruiterWebSocket();
    
    return () => {
      if (websocket) {
        websocket.close();
      }
    };
  }, []);

  const fetchMonitoringData = async () => {
    try {
      const response = await axios.get(`${API}/interviews/${interview.id}/monitoring`);
      setMonitoringData(response.data);
      setSecurityViolations(response.data.security_violations || []);
      setIsLive(response.data.is_live || false);
    } catch (error) {
      console.error('Failed to fetch monitoring data:', error);
    }
  };

  const initializeRecruiterWebSocket = () => {
    const wsUrl = `${BACKEND_URL.replace('https://', 'wss://').replace('http://', 'ws://')}/api/interviews/${interview.id}/ws/recruiter`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log('Recruiter monitoring connected');
      setIsLive(true);
    };

    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      handleCandidateUpdate(message);
    };

    ws.onerror = (error) => {
      console.error('Recruiter WebSocket error:', error);
      setIsLive(false);
    };

    ws.onclose = () => {
      console.log('Recruiter monitoring disconnected');
      setIsLive(false);
    };

    setWebsocket(ws);
  };

  const handleCandidateUpdate = (message) => {
    switch (message.type) {
      case 'security_violation':
        setSecurityViolations(prev => [...prev, message.violation]);
        break;
      case 'interview_started':
        setIsLive(true);
        break;
      case 'interview_ended':
        setIsLive(false);
        break;
      default:
        console.log('Received candidate update:', message);
    }
  };

  const sendCommandToCandidate = (command) => {
    if (websocket && websocket.readyState === WebSocket.OPEN) {
      websocket.send(JSON.stringify(command));
    }
  };

  const endInterviewFromRecruiter = () => {
    if (window.confirm('Are you sure you want to end this interview? This will terminate the candidate session.')) {
      sendCommandToCandidate({ type: 'end_interview' });
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'warning': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  if (!monitoringData) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <Shield className="w-12 h-12 mx-auto mb-4 animate-spin" />
          <p>Loading interview monitoring...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <div className="bg-slate-800 p-4 border-b border-slate-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button onClick={onClose} variant="outline" size="sm" className="border-slate-600 text-slate-300">
              <X className="w-4 h-4 mr-2" />
              Close Monitor
            </Button>
            <div className="flex items-center space-x-2">
              <Shield className="w-6 h-6 text-purple-400" />
              <h1 className="text-xl font-bold">Live Interview Monitor</h1>
            </div>
            {isLive && (
              <Badge className="bg-red-600 text-white animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full mr-2"></div>
                LIVE
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge className="bg-slate-700 text-slate-300">
              Interview ID: {interview.id.slice(-8)}
            </Badge>
            <Button
              onClick={() => window.open(`/recordings/${interview.id}`, '_blank')}
              variant="outline"
              className="border-slate-600 text-slate-300"
              size="sm"
            >
              View Recordings
            </Button>
            <Button 
              onClick={endInterviewFromRecruiter}
              className="bg-red-600 hover:bg-red-700"
              size="sm"
            >
              End Interview
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-4 gap-6 h-screen">
          {/* Candidate Info & Controls */}
          <div className="space-y-4">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <User className="w-5 h-5 text-blue-400" />
                  <span>Candidate Info</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {monitoringData.candidate && (
                  <div className="space-y-3 text-sm">
                    <div>
                      <Label className="text-slate-400">Name</Label>
                      <p className="text-white font-medium">{monitoringData.candidate.full_name}</p>
                    </div>
                    <div>
                      <Label className="text-slate-400">Email</Label>
                      <p className="text-slate-300">{monitoringData.candidate.email}</p>
                    </div>
                    <div>
                      <Label className="text-slate-400">Experience</Label>
                      <p className="text-slate-300">{monitoringData.candidate.experience_years} years</p>
                    </div>
                    <div>
                      <Label className="text-slate-400">Current Title</Label>
                      <p className="text-slate-300">{monitoringData.candidate.current_title}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Security Status */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-green-400" />
                  <span>Security Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-300">Recording Status</span>
                  {isLive ? (
                    <CheckCircle className="w-4 h-4 text-green-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-300">Screen Monitoring</span>
                  <CheckCircle className="w-4 h-4 text-green-400" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-300">Video Monitoring</span>
                  <CheckCircle className="w-4 h-4 text-green-400" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-300">Violations</span>
                  <Badge className={securityViolations.length > 0 ? "bg-red-600" : "bg-green-600"}>
                    {securityViolations.length}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Interview Controls */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Video className="w-5 h-5 text-purple-400" />
                  <span>Interview Controls</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => sendCommandToCandidate({type: 'security_alert', message: 'Please maintain focus on the interview'})}
                >
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Send Focus Alert
                </Button>
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => fetchMonitoringData()}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Refresh Data
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Live Video Feeds */}
          <div className="col-span-2 space-y-4">
            {/* Candidate Video */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Camera className="w-5 h-5 text-green-400" />
                  <span>Candidate Video Feed</span>
                  {isLive && (
                    <div className="flex items-center space-x-1 text-red-400">
                      <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                      <span className="text-sm">LIVE</span>
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-slate-900 rounded-lg border-2 border-green-500 flex items-center justify-center">
                  {isLive ? (
                    <video
                      ref={candidateVideoRef}
                      className="w-full h-full rounded-lg"
                      autoPlay
                      muted
                      playsInline
                    />
                  ) : (
                    <div className="text-center text-slate-400">
                      <Camera className="w-12 h-12 mx-auto mb-2" />
                      <p>No live video feed</p>
                      <p className="text-sm">Interview not in progress</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Candidate Screen */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Monitor className="w-5 h-5 text-blue-400" />
                  <span>Candidate Screen Share</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-video bg-slate-900 rounded-lg border-2 border-blue-500 flex items-center justify-center">
                  {isLive ? (
                    <video
                      ref={candidateScreenRef}
                      className="w-full h-full rounded-lg"
                      autoPlay
                      muted
                      playsInline
                    />
                  ) : (
                    <div className="text-center text-slate-400">
                      <Monitor className="w-12 h-12 mx-auto mb-2" />
                      <p>No screen sharing active</p>
                      <p className="text-sm">Interview not in progress</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Security Violations Log */}
          <div>
            <Card className="bg-slate-800 border-slate-700 h-full">
              <CardHeader>
                <CardTitle className="text-white flex items-center space-x-2">
                  <Eye className="w-5 h-5 text-orange-400" />
                  <span>Security Log</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="max-h-96 overflow-y-auto space-y-2">
                  {securityViolations.length > 0 ? securityViolations.slice(-10).reverse().map((violation, index) => (
                    <div key={index} className={`text-xs p-3 rounded border ${getSeverityColor(violation.severity)}`}>
                      <div className="font-medium">{violation.violation_type}</div>
                      <div className="text-xs opacity-80 mb-1">{violation.description}</div>
                      <div className="text-xs opacity-70">
                        {new Date(violation.timestamp).toLocaleTimeString()}
                      </div>
                    </div>
                  )) : (
                    <div className="text-slate-400 text-sm text-center py-8">
                      <Shield className="w-8 h-8 mx-auto mb-2" />
                      <p>No security violations</p>
                      <p className="text-xs">All systems secure</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

// Candidate Profile Component
const CandidateProfile = ({ user }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState(user || {});
  const [resumeUploading, setResumeUploading] = useState(false);
  const [resumeFile, setResumeFile] = useState(null);

  const handleSave = async () => {
    try {
      await axios.put(`${API}/candidates/profile`, profileData);
      alert('Profile updated successfully!');
      setIsEditing(false);
    } catch (error) {
      alert('Failed to update profile: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleResumeUpload = async () => {
    if (!resumeFile) {
      alert('Please choose a resume file to upload');
      return;
    }
    try {
      setResumeUploading(true);
      const form = new FormData();
      form.append('file', resumeFile);
      await axios.post(`${API}/candidates/resume`, form, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`
        }
      });
      alert('Resume uploaded successfully');
      setResumeFile(null);
    } catch (error) {
      alert(error.response?.data?.detail || 'Failed to upload resume');
    } finally {
      setResumeUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-slate-800">My Profile</h2>
        <Button
          onClick={() => isEditing ? handleSave() : setIsEditing(true)}
          className="bg-gradient-to-r from-teal-600 to-purple-600 hover:from-teal-700 hover:to-purple-700 text-white"
        >
          {isEditing ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Save Changes
            </>
          ) : (
            <>
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </>
          )}
        </Button>
      </div>

      {/* Verification Status */}
      <Card className="border-0 shadow-lg bg-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Verified className="w-5 h-5 text-teal-600" />
            <span>Verification Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-800">Email</p>
                  <p className="text-sm text-green-600">{user?.email}</p>
                </div>
              </div>
              {user?.is_email_verified ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <Button size="sm" variant="outline" className="border-green-300 text-green-700">
                  Verify
                </Button>
              )}
            </div>

            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-blue-800">Phone</p>
                  <p className="text-sm text-blue-600">{user?.phone}</p>
                </div>
              </div>
              {user?.is_phone_verified ? (
                <CheckCircle className="w-5 h-5 text-blue-600" />
              ) : (
                <Button size="sm" variant="outline" className="border-blue-300 text-blue-700">
                  Verify
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Information */}
      <Card className="border-0 shadow-lg bg-white">
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Keep your profile up-to-date to attract the right opportunities</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="full_name">Full Name</Label>
              <Input
                id="full_name"
                value={profileData.full_name || ''}
                onChange={(e) => setProfileData({...profileData, full_name: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="current_title">Current Title</Label>
              <Input
                id="current_title"
                value={profileData.current_title || ''}
                onChange={(e) => setProfileData({...profileData, current_title: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="current_company">Current Company</Label>
              <Input
                id="current_company"
                value={profileData.current_company || ''}
                onChange={(e) => setProfileData({...profileData, current_company: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profileData.location || ''}
                onChange={(e) => setProfileData({...profileData, location: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>

            <div className="col-span-2">
              <Label>Resume</Label>
              <div className="mt-1 flex items-center space-x-3">
                <Input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setResumeFile(e.target.files?.[0] || null)} />
                <Button onClick={handleResumeUpload} disabled={resumeUploading} className="bg-gradient-to-r from-purple-600 to-teal-600 text-white">
                  {resumeUploading ? 'Uploading...' : 'Upload Resume'}
                </Button>
              </div>
              <p className="text-xs text-slate-500 mt-1">Accepted: PDF/DOC/DOCX. Recruiters for jobs you apply to can download this.</p>
            </div>

            <div>
              <Label htmlFor="experience_years">Years of Experience</Label>
              <Input
                id="experience_years"
                type="number"
                value={profileData.experience_years || ''}
                onChange={(e) => setProfileData({...profileData, experience_years: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="expected_salary">Expected Salary</Label>
              <Input
                id="expected_salary"
                type="number"
                value={profileData.expected_salary || ''}
                onChange={(e) => setProfileData({...profileData, expected_salary: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
                placeholder="120000"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="bio">Professional Bio</Label>
            <Textarea
              id="bio"
              value={profileData.bio || ''}
              onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
              disabled={!isEditing}
              className="mt-1"
              rows={4}
              placeholder="Tell employers about your professional background and goals..."
            />
          </div>

          <div>
            <Label htmlFor="skills">Skills</Label>
            <Input
              id="skills"
              value={Array.isArray(profileData.skills) ? profileData.skills.join(', ') : ''}
              onChange={(e) => setProfileData({...profileData, skills: e.target.value.split(',').map(s => s.trim())})}
              disabled={!isEditing}
              className="mt-1"
              placeholder="React, Python, JavaScript, Node.js"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="linkedin_url">LinkedIn URL</Label>
              <Input
                id="linkedin_url"
                type="url"
                value={profileData.linkedin_url || ''}
                onChange={(e) => setProfileData({...profileData, linkedin_url: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
                placeholder="https://linkedin.com/in/yourprofile"
              />
            </div>

            <div>
              <Label htmlFor="portfolio_url">Portfolio URL</Label>
              <Input
                id="portfolio_url"
                type="url"
                value={profileData.portfolio_url || ''}
                onChange={(e) => setProfileData({...profileData, portfolio_url: e.target.value})}
                disabled={!isEditing}
                className="mt-1"
                placeholder="https://yourportfolio.com"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Main ATS Dashboard
const ATSDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [analytics, setAnalytics] = useState({});
  const [jobs, setJobs] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [applications, setApplications] = useState([]);
  const [selectedInterview, setSelectedInterview] = useState(null);
  const [showInterviewMonitor, setShowInterviewMonitor] = useState(false);
  const [aiMonitoringData, setAiMonitoringData] = useState({});
  const [activeSessions, setActiveSessions] = useState([]);
  const [showCreateJob, setShowCreateJob] = useState(false);
  const [newJob, setNewJob] = useState({
    title: '',
    description: '',
    location: 'Remote',
    job_type: 'Full-time',
    experience_level: 'Mid',
    salary_min: '',
    salary_max: '',
    skills: ''
  });
  const [upcomingInterviews, setUpcomingInterviews] = useState([]);
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState(null);
  const { user, company, logout } = useAuth();

  // Question Sets Manager state (used by Question Sets tab)
  const [qsSets, setQsSets] = useState([]);
  const [qsLoading, setQsLoading] = useState(false);
  const [qsEditingId, setQsEditingId] = useState(null);
  const [qsForm, setQsForm] = useState({
    name: '',
    description: '',
    questions: [{ text: '', type: 'text', max_duration_sec: 90 }],
  });

  const fetchQuestionSets = async () => {
    try {
      setQsLoading(true);
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` };
      const res = await axios.get(`${API}/question-sets`, { headers });
      setQsSets(res.data || []);
    } catch (e) {
      console.error('Failed to fetch question sets:', e);
    } finally {
      setQsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'question-sets') {
      fetchQuestionSets();
    }
  }, [activeTab]);

  const resetQsForm = () => {
    setQsEditingId(null);
    setQsForm({ name: '', description: '', questions: [{ text: '', type: 'text', max_duration_sec: 90 }] });
  };

  const addQuestionRow = () => {
    setQsForm(prev => ({ ...prev, questions: [...prev.questions, { text: '', type: 'text', max_duration_sec: 90 }] }));
  };

  const updateQuestionRow = (idx, field, value) => {
    setQsForm(prev => {
      const next = [...prev.questions];
      next[idx] = { ...next[idx], [field]: field === 'max_duration_sec' ? Number(value) || 0 : value };
      return { ...prev, questions: next };
    });
  };

  const removeQuestionRow = (idx) => {
    setQsForm(prev => ({ ...prev, questions: prev.questions.filter((_, i) => i !== idx) }));
  };

  const saveQuestionSet = async () => {
    try {
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` };
      const payload = {
        name: qsForm.name,
        description: qsForm.description,
        questions: qsForm.questions.map(q => ({ text: q.text, type: q.type, max_duration_sec: Number(q.max_duration_sec) || 0 })),
      };
      if (qsEditingId) {
        await axios.put(`${API}/question-sets/${qsEditingId}`, payload, { headers });
      } else {
        await axios.post(`${API}/question-sets`, payload, { headers });
      }
      await fetchQuestionSets();
      setQsEditingId(null);
      setQsForm({ name: '', description: '', questions: [{ text: '', type: 'text', max_duration_sec: 90 }] });
      alert('Question set saved');
    } catch (e) {
      alert(e.response?.data?.detail || 'Failed to save question set');
    }
  };

  const editQuestionSet = (qs) => {
    setQsEditingId(qs.id);
    setQsForm({
      name: qs.name || '',
      description: qs.description || '',
      questions: (qs.questions || []).map(q => ({ text: q.text || '', type: q.type || 'text', max_duration_sec: q.max_duration_sec || 90 })),
    });
  };

  const deleteQuestionSet = async (qsId) => {
    if (!window.confirm('Delete this question set?')) return;
    try {
      const headers = { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` };
      await axios.delete(`${API}/question-sets/${qsId}`, { headers });
      await fetchQuestionSets();
      if (qsEditingId === qsId) {
        setQsEditingId(null);
        setQsForm({ name: '', description: '', questions: [{ text: '', type: 'text', max_duration_sec: 90 }] });
      }
    } catch (e) {
      alert(e.response?.data?.detail || 'Failed to delete question set');
    }
  };

  

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Removed a DOM-manipulation useEffect that removed header nodes, which conflicted with React DOM reconciliation and caused NotFoundError removeChild.

  const fetchDashboardData = async () => {
    try {
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };

      const [analyticsRes, jobsRes, candidatesRes, applicationsRes, interviewsRes] = await Promise.all([
        axios.get(`${API}/analytics/dashboard`, { headers }),
        axios.get(`${API}/jobs`, { headers }),
        axios.get(`${API}/candidates`, { headers }),
        axios.get(`${API}/applications`, { headers }),
        axios.get(`${API}/interviews/upcoming`, { headers })
      ]);

      setAnalytics(analyticsRes.data);
      setJobs(jobsRes.data);
      setCandidates(candidatesRes.data);
      setApplications(applicationsRes.data);
      setUpcomingInterviews(interviewsRes.data);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
  };

  const seedData = async () => {
    try {
      await axios.post(`${API}/seed/data`);
      alert('Demo data created successfully!');
      fetchDashboardData();
    } catch (error) {
      alert('Failed to seed data: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleMonitorInterview = (interview) => {
    setSelectedInterview(interview);
    setShowInterviewMonitor(true);
  };

  const closeInterviewMonitor = () => {
    setShowInterviewMonitor(false);
    setSelectedInterview(null);
  };

  const fetchAIMonitoringData = async () => {
    try {
      const response = await axios.get(`${API}/analytics/ai-monitoring`);
      setAiMonitoringData(response.data);
    } catch (error) {
      console.error('Failed to fetch AI monitoring data:', error);
    }
  };

  const fetchActiveSessions = async () => {
    try {
      const response = await axios.get(`${API}/secure-interview/active-sessions`);
      setActiveSessions(response.data);
    } catch (error) {
      console.error('Failed to fetch active sessions:', error);
    }
  };

  const getAIDecision = async (sessionId) => {
    try {
      const response = await axios.post(`${API}/secure-interview/${sessionId}/ai-decision`);
      return response.data;
    } catch (error) {
      console.error('Failed to get AI decision:', error);
      return null;
    }
  };

  const fetchUpcomingInterviews = async () => {
    try {
      const response = await axios.get(`${API}/interviews/upcoming`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
          'Content-Type': 'application/json'
        }
      });
      setUpcomingInterviews(response.data);
    } catch (error) {
      console.error('Failed to fetch upcoming interviews:', error);
    }
  };

  const scheduleInterview = async (applicationId, scheduledDate, duration = 60, type = 'video') => {
    try {
      const response = await axios.post(`${API}/interviews/schedule`, {
        application_id: applicationId,
        scheduled_date: scheduledDate,
        duration_minutes: duration,
        interview_type: type
      }, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      alert('Interview scheduled successfully!');
      fetchDashboardData();
      fetchUpcomingInterviews();
      setShowScheduleDialog(false);
    } catch (error) {
      console.error('Failed to schedule interview:', error);
      alert(error.response?.data?.detail || 'Failed to schedule interview');
    }
  };

  // Quick create job using prompts (temporary MVP)
  const createQuickJob = async () => {
    try {
      const title = window.prompt('Job Title:', 'Software Engineer');
      if (!title) return;
      const description = window.prompt('Job Description:', 'Build and ship features.');
      if (!description) return;

      const jobPayload = {
        title,
        description,
        requirements: ['Strong problem solving', 'Team collaboration'],
        location: 'Remote',
        job_type: 'Full-time',
        salary_min: 60000,
        salary_max: 90000,
        skills: ['JavaScript', 'React'],
        department: 'Engineering',
        experience_level: 'Mid',
        status: 'draft'
      };

      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };

      const createRes = await axios.post(`${API}/jobs`, jobPayload, { headers });
      const job = createRes.data;

      await axios.post(`${API}/jobs/${job.id}/publish`, {}, { headers });
      alert('Job created and published successfully!');
      fetchDashboardData();
    } catch (error) {
      console.error('Failed to create job:', error);
      alert(error.response?.data?.detail || 'Failed to create job');
    }
  };

  // Full create job using modal form
  const createJob = async () => {
    try {
      const headers = {
        'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}`,
        'Content-Type': 'application/json'
      };

      // Normalize fields to satisfy backend Job model
      const skillsArray = Array.isArray(newJob.skills)
        ? newJob.skills
        : (newJob.skills || '')
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean);
      const requirementsArray = Array.isArray(newJob.requirements) ? newJob.requirements : [];

      const payload = {
        title: (newJob.title || '').trim(),
        description: (newJob.description || '').trim(),
        requirements: requirementsArray,
        location: newJob.location || 'Remote',
        job_type: newJob.job_type || 'Full-time',
        skills: skillsArray.length ? skillsArray : ['General'],
        department: newJob.department || 'Engineering',
        experience_level: newJob.experience_level || 'Mid',
        salary_min: newJob.salary_min ? Number(newJob.salary_min) : undefined,
        salary_max: newJob.salary_max ? Number(newJob.salary_max) : undefined,
        status: 'draft'
      };

      const res = await axios.post(`${API}/jobs`, payload, { headers });
      const job = res.data;
      await axios.post(`${API}/jobs/${job.id}/publish`, {}, { headers });
      alert('Job created successfully');
      setShowCreateJob(false);
      setNewJob({ title: '', description: '', location: 'Remote', job_type: 'Full-time', experience_level: 'Mid', salary_min: '', salary_max: '', skills: '' });
      fetchDashboardData();
    } catch (error) {
      console.error('Failed to create job:', error);
      const backendDetail = error.response?.data?.detail || error.response?.data?.message;
      alert(backendDetail || 'Failed to create job. Please ensure title, description, department, experience_level, and skills are provided.');
    }
  };

  // Show interview monitor if selected
  if (showInterviewMonitor && selectedInterview) {
    return <RecruiterInterviewMonitor interview={selectedInterview} onClose={closeInterviewMonitor} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-purple-50/20">
      {/* Header */}
      <header className="bg-white border-b border-purple-200 px-6 py-4 shadow-sm ats-header">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Shield className="w-8 h-8 text-purple-600" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-teal-600 to-orange-500 bg-clip-text text-transparent">SecuHire</h1>
              <p className="text-sm text-slate-600">{company?.name}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4 ats-header-actions">
            <div className="text-right">
              <p className="text-sm text-slate-600">Welcome back,</p>
              <p className="font-semibold text-slate-800">{user?.full_name}</p>
            </div>
            <Button
              variant="outline"
              className="border-purple-300 text-purple-700 hover:bg-purple-50"
              onClick={() => { logout(); navigate('/auth', { replace: true }); }}
            >
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="px-6 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Main Navigation Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid grid-cols-8 w-full max-w-4xl bg-white border border-purple-200 shadow-sm">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Dashboard</TabsTrigger>
              <TabsTrigger value="jobs" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Jobs</TabsTrigger>
              <TabsTrigger value="candidates" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Candidates</TabsTrigger>
              <TabsTrigger value="pipeline" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Pipeline</TabsTrigger>
              <TabsTrigger value="interviews" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Interviews</TabsTrigger>
              <TabsTrigger value="question-sets" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Question Sets</TabsTrigger>
              <TabsTrigger value="ai-monitoring" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">AI Monitoring</TabsTrigger>
              <TabsTrigger value="analytics" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">Analytics</TabsTrigger>
            </TabsList>

            {/* Dashboard Overview */}
            <TabsContent value="dashboard" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Dashboard Overview</h2>
                <div className="flex space-x-2">
                  <Button 
                    onClick={() => {
                      fetchUpcomingInterviews();
                      fetchAIMonitoringData();
                      fetchActiveSessions();
                    }}
                    variant="outline"
                    className="border-purple-300 text-purple-700 hover:bg-purple-50"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Refresh
                  </Button>
                  <Button onClick={seedData} className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Demo Data
                  </Button>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid md:grid-cols-4 gap-6">
                <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-purple-50/50 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 font-medium">Active Jobs</p>
                        <p className="text-3xl font-bold text-slate-800">{analytics.overview?.active_jobs || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                        <Briefcase className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-teal-50/50 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 font-medium">Total Candidates</p>
                        <p className="text-3xl font-bold text-slate-800">{analytics.overview?.total_candidates || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-teal-600 rounded-xl flex items-center justify-center">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-orange-50/50 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 font-medium">Applications</p>
                        <p className="text-3xl font-bold text-slate-800">{analytics.overview?.total_applications || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-pink-500 rounded-xl flex items-center justify-center">
                        <FileText className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-green-50/50 hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 font-medium">Recent Hires</p>
                        <p className="text-3xl font-bold text-slate-800">{analytics.recent_activity?.hires_30_days || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-600 rounded-xl flex items-center justify-center">
                        <Award className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Pipeline Overview */}
              {analytics.pipeline && (
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="text-slate-800">Hiring Pipeline Overview</CardTitle>
                    <CardDescription>Applications by stage</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-4 gap-4">
                      {Object.entries(analytics.pipeline).map(([stage, count]) => (
                        <div key={stage} className="text-center p-4 bg-gradient-to-br from-slate-50 to-purple-50/30 rounded-xl border border-purple-100">
                          <div className="text-2xl font-bold text-slate-800">{count}</div>
                          <div className="text-sm text-slate-600 capitalize font-medium">{stage.replace('_', ' ')}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Jobs Management */}
            <TabsContent value="jobs" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Jobs Management</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Job
                </Button>
              </div>

              <div className="grid gap-6">
                {jobs.length > 0 ? jobs.map((job) => (
                  <JobCard key={job.id} job={job} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <Briefcase className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No jobs yet</h3>
                      <p className="text-slate-500 mb-4">Create your first job posting to get started</p>
                      <Button onClick={() => setShowCreateJob(true)} className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white">Create Your First Job</Button>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Create Job Modal */}
              <Dialog open={showCreateJob} onOpenChange={setShowCreateJob}>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create Job</DialogTitle>
                    <DialogDescription>Fill in the details and publish to make it visible to candidates.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Title</Label>
                      <Input value={newJob.title} onChange={(e) => setNewJob({ ...newJob, title: e.target.value })} />
                    </div>
                    <div>
                      <Label>Description</Label>
                      <Textarea value={newJob.description} onChange={(e) => setNewJob({ ...newJob, description: e.target.value })} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Location</Label>
                        <Input value={newJob.location} onChange={(e) => setNewJob({ ...newJob, location: e.target.value })} />
                      </div>
                      <div>
                        <Label>Job Type</Label>
                        <Select value={newJob.job_type} onValueChange={(v) => setNewJob({ ...newJob, job_type: v })}>
                          <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Full-time">Full-time</SelectItem>
                            <SelectItem value="Part-time">Part-time</SelectItem>
                            <SelectItem value="Contract">Contract</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Experience Level</Label>
                        <Select value={newJob.experience_level} onValueChange={(v) => setNewJob({ ...newJob, experience_level: v })}>
                          <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Entry">Entry</SelectItem>
                            <SelectItem value="Mid">Mid</SelectItem>
                            <SelectItem value="Senior">Senior</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Skills (comma-separated)</Label>
                        <Input value={newJob.skills} onChange={(e) => setNewJob({ ...newJob, skills: e.target.value })} placeholder="React, Node.js, SQL" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Salary Min</Label>
                        <Input type="number" value={newJob.salary_min} onChange={(e) => setNewJob({ ...newJob, salary_min: e.target.value })} />
                      </div>
                      <div>
                        <Label>Salary Max</Label>
                        <Input type="number" value={newJob.salary_max} onChange={(e) => setNewJob({ ...newJob, salary_max: e.target.value })} />
                      </div>
                    </div>
                    <div className="flex justify-end space-x-2 pt-2">
                      <Button variant="outline" onClick={() => setShowCreateJob(false)}>Cancel</Button>
                      <Button onClick={createJob} className="bg-gradient-to-r from-purple-600 to-teal-600 text-white">Create & Publish</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </TabsContent>

            {/* Candidates Database */}
            <TabsContent value="candidates" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Candidate Database</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Candidate
                </Button>
              </div>

              {/* Search and Filters */}
              <div className="flex space-x-4">
                <div className="flex-1 relative">
                  <Search className="w-5 h-5 absolute left-3 top-3 text-slate-400" />
                  <Input placeholder="Search candidates..." className="pl-10 border-purple-200 focus:border-purple-500 focus:ring-purple-500" />
                </div>
                <Button variant="outline" className="border-purple-300 text-purple-700 hover:bg-purple-50">
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                </Button>
              </div>

              <div className="grid gap-6">
                {candidates.length > 0 ? candidates.map((candidate) => (
                  <CandidateCard key={candidate.id} candidate={candidate} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <Users className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No candidates yet</h3>
                      <p className="text-slate-500 mb-4">Add candidates to build your talent pipeline</p>
                      <Button className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white">Add First Candidate</Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Pipeline Management */}
            <TabsContent value="pipeline" className="space-y-6">
              <h2 className="text-3xl font-bold text-slate-800">Hiring Pipeline</h2>
              
              <div className="grid gap-6">
                {applications.length > 0 ? applications.map((item, index) => (
                  <ApplicationCard key={index} application={item.application} candidate={item.candidate} job={item.job} />
                )) : (
                  <Card className="border-0 shadow-lg bg-white">
                    <CardContent className="p-12 text-center">
                      <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                        <Target className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">No applications yet</h3>
                      <p className="text-slate-500 mb-4">Applications will appear here once candidates apply</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            {/* Interviews */}
            <TabsContent value="interviews" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Interviews</h2>
              </div>
              <div className="mt-4">
                <RecruiterInterviews />
              </div>
            </TabsContent>

            {/* Question Sets Manager */}
            <TabsContent value="question-sets" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">Question Sets</h2>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    className="border-purple-300 text-purple-700 hover:bg-purple-50"
                    onClick={resetQsForm}
                  >
                    Clear Form
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white"
                    onClick={saveQuestionSet}
                    disabled={qsLoading}
                  >
                    {qsEditingId ? 'Update Set' : 'Create Set'}
                  </Button>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Existing Sets List */}
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="text-slate-800">Existing Question Sets</CardTitle>
                    <CardDescription>Manage question banks used for aptitude rounds and interviews.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {qsLoading ? (
                      <p className="text-slate-500 text-sm">Loading question sets...</p>
                    ) : qsSets.length === 0 ? (
                      <p className="text-slate-500 text-sm">No question sets yet. Create your first set on the right.</p>
                    ) : (
                      <div className="space-y-3">
                        {qsSets.map((qs) => (
                          <div
                            key={qs.id}
                            className="flex items-start justify-between p-3 rounded-lg border border-slate-100 hover:border-purple-200 hover:bg-purple-50/40 transition-colors"
                          >
                            <div>
                              <div className="flex items-center space-x-2">
                                <h3 className="font-semibold text-slate-800">{qs.name}</h3>
                                <Badge className="bg-purple-100 text-purple-800 border-purple-200 text-xs">
                                  {(qs.questions || []).length} questions
                                </Badge>
                              </div>
                              {qs.description && (
                                <p className="text-xs text-slate-500 mt-1 line-clamp-2">{qs.description}</p>
                              )}
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => editQuestionSet(qs)}
                              >
                                Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600 border-red-200 hover:bg-red-50"
                                onClick={() => deleteQuestionSet(qs.id)}
                              >
                                Delete
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Create / Edit Form */}
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="text-slate-800">
                      {qsEditingId ? 'Edit Question Set' : 'Create Question Set'}
                    </CardTitle>
                    <CardDescription>
                      Define a set of questions with optional per-question time limits.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-slate-700">Name</Label>
                      <Input
                        value={qsForm.name}
                        onChange={(e) => setQsForm({ ...qsForm, name: e.target.value })}
                        placeholder="e.g. General Aptitude Round 1"
                      />
                    </div>
                    <div>
                      <Label className="text-slate-700">Description</Label>
                      <Textarea
                        value={qsForm.description}
                        onChange={(e) => setQsForm({ ...qsForm, description: e.target.value })}
                        placeholder="Optional notes about this question set"
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-slate-700">Questions</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={addQuestionRow}
                        >
                          <Plus className="w-4 h-4 mr-1" /> Add Question
                        </Button>
                      </div>

                      <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                        {qsForm.questions.map((q, idx) => (
                          <div
                            key={idx}
                            className="p-3 rounded-lg border border-slate-200 bg-slate-50/60 space-y-2"
                          >
                            <div className="flex justify-between items-center">
                              <span className="text-xs font-medium text-slate-500">Question {idx + 1}</span>
                              {qsForm.questions.length > 1 && (
                                <button
                                  type="button"
                                  className="text-xs text-red-600 hover:underline"
                                  onClick={() => removeQuestionRow(idx)}
                                >
                                  Remove
                                </button>
                              )}
                            </div>
                            <Textarea
                              value={q.text}
                              onChange={(e) => updateQuestionRow(idx, 'text', e.target.value)}
                              placeholder="Enter question text"
                              className="text-sm"
                            />
                            <div className="grid grid-cols-2 gap-3 items-center">
                              <div>
                                <Label className="text-xs text-slate-600">Type</Label>
                                <Select
                                  value={q.type}
                                  onValueChange={(val) => updateQuestionRow(idx, 'type', val)}
                                >
                                  <SelectTrigger className="h-8 text-xs">
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="text">Text</SelectItem>
                                    <SelectItem value="mcq">MCQ</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label className="text-xs text-slate-600">Max Duration (sec)</Label>
                                <Input
                                  type="number"
                                  min={0}
                                  value={q.max_duration_sec}
                                  onChange={(e) => updateQuestionRow(idx, 'max_duration_sec', e.target.value)}
                                  className="h-8 text-xs"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* AI Monitoring */}
            <TabsContent value="ai-monitoring" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-bold text-slate-800">AI Monitoring Center</h2>
                <Button 
                  onClick={() => {
                    fetchAIMonitoringData();
                    fetchActiveSessions();
                  }}
                  className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Refresh Data
                </Button>
              </div>

              {/* Active Sessions */}
              <Card className="border-0 shadow-lg bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Shield className="w-6 h-6 text-purple-600" />
                    <span>Active Secure Sessions</span>
                    <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                      {activeSessions.length} active
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {activeSessions.length > 0 ? (
                    <div className="grid gap-4">
                      {activeSessions.map((session) => (
                        <Card key={session.id} className="border border-purple-200 bg-purple-50">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-semibold text-slate-800">Session {session.id.slice(0, 8)}</h4>
                                <p className="text-sm text-slate-600">
                                  Started: {new Date(session.session_start).toLocaleString()}
                                </p>
                                <div className="flex items-center space-x-4 mt-2">
                                  <Badge className="bg-green-100 text-green-800">
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Active
                                  </Badge>
                                  <Badge className="bg-blue-100 text-blue-800">
                                    <Camera className="w-3 h-3 mr-1" />
                                    Webcam
                                  </Badge>
                                  <Badge className="bg-orange-100 text-orange-800">
                                    <Monitor className="w-3 h-3 mr-1" />
                                    Screen Share
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => getAIDecision(session.id)}
                                >
                                  <Brain className="w-4 h-4 mr-2" />
                                  Get AI Decision
                                </Button>
                                <Button 
                                  size="sm"
                                  onClick={() => handleMonitorInterview(session)}
                                >
                                  <Eye className="w-4 h-4 mr-2" />
                                  Monitor
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Shield className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-slate-600 mb-2">No Active Sessions</h3>
                      <p className="text-slate-500">Secure interview sessions will appear here when candidates join</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* AI Analysis Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Eye className="w-5 h-5 text-blue-600" />
                      <span>Facial Analysis</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      {aiMonitoringData.facial_accuracy || '85.2'}%
                    </div>
                    <p className="text-sm text-slate-600">Average attention score</p>
                    <Progress value={aiMonitoringData.facial_accuracy || 85.2} className="mt-2" />
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Volume2 className="w-5 h-5 text-green-600" />
                      <span>Voice Analysis</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600 mb-2">
                      {aiMonitoringData.voice_authenticity || '92.1'}%
                    </div>
                    <p className="text-sm text-slate-600">Voice authenticity score</p>
                    <Progress value={aiMonitoringData.voice_authenticity || 92.1} className="mt-2" />
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Monitor className="w-5 h-5 text-orange-600" />
                      <span>Screen Monitoring</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-orange-600 mb-2">
                      {aiMonitoringData.screen_focus || '78.5'}%
                    </div>
                    <p className="text-sm text-slate-600">Focus and compliance score</p>
                    <Progress value={aiMonitoringData.screen_focus || 78.5} className="mt-2" />
                  </CardContent>
                </Card>
              </div>

              {/* Security Violations */}
              <Card className="border-0 shadow-lg bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="w-6 h-6 text-red-600" />
                    <span>Security Violations</span>
                    <Badge className="bg-red-100 text-red-800 border-red-200">
                      {aiMonitoringData.violations_count || 0} detected
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {aiMonitoringData.violations && aiMonitoringData.violations.length > 0 ? (
                      aiMonitoringData.violations.map((violation, index) => (
                        <Alert key={index} className={
                          violation.severity === 'critical' ? 'border-red-200 bg-red-50' :
                          violation.severity === 'warning' ? 'border-yellow-200 bg-yellow-50' :
                          'border-blue-200 bg-blue-50'
                        }>
                          <AlertTriangle className="w-4 h-4" />
                          <AlertDescription>
                            <div className="flex justify-between items-center">
                              <span>{violation.description}</span>
                              <Badge className={
                                violation.severity === 'critical' ? 'bg-red-100 text-red-800' :
                                violation.severity === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-blue-100 text-blue-800'
                              }>
                                {violation.severity}
                              </Badge>
                            </div>
                          </AlertDescription>
                        </Alert>
                      ))
                    ) : (
                      <div className="text-center py-4">
                        <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                        <p className="text-slate-600">No security violations detected</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics */}
            <TabsContent value="analytics" className="space-y-6">
              <h2 className="text-3xl font-bold text-slate-800">Analytics & Reports</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="text-slate-800">Hiring Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Time to Hire (avg)</span>
                        <span className="font-medium text-slate-800">14 days</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Applications per Job</span>
                        <span className="font-medium text-slate-800">25</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Interview to Hire Ratio</span>
                        <span className="font-medium text-slate-800">3:1</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Upcoming Interviews */}
                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <CalendarIcon className="w-6 h-6 text-purple-600" />
                      <span>Upcoming Interviews</span>
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                        {upcomingInterviews.length} scheduled
                      </Badge>
                    </CardTitle>
                    <CardDescription>Interviews scheduled for the next few days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {upcomingInterviews.length > 0 ? (
                      <div className="space-y-4">
                        {upcomingInterviews.slice(0, 5).map((item, index) => {
                          const { interview, candidate, job } = item;
                          const interviewDate = new Date(interview.scheduled_date);
                          const isToday = interviewDate.toDateString() === new Date().toDateString();
                          const isTomorrow = interviewDate.toDateString() === new Date(Date.now() + 86400000).toDateString();
                          
                          return (
                            <Card key={index} className={`border-l-4 ${
                              isToday ? 'border-l-green-500 bg-green-50' : 
                              isTomorrow ? 'border-l-blue-500 bg-blue-50' : 
                              'border-l-purple-500 bg-purple-50'
                            }`}>
                              <CardContent className="p-4">
                                <div className="flex items-center justify-between">
                                  <div className="flex-1">
                                    <div className="flex items-center space-x-3">
                                      <div>
                                        <h4 className="font-semibold text-slate-800">
                                          {candidate?.full_name || 'Unknown Candidate'}
                                        </h4>
                                        <p className="text-sm text-slate-600">
                                          {job?.title || 'Unknown Position'}
                                        </p>
                                      </div>
                                      <Badge className={
                                        isToday ? 'bg-green-100 text-green-800' :
                                        isTomorrow ? 'bg-blue-100 text-blue-800' :
                                        'bg-purple-100 text-purple-800'
                                      }>
                                        {isToday ? 'Today' : isTomorrow ? 'Tomorrow' : interviewDate.toLocaleDateString()}
                                      </Badge>
                                    </div>
                                    <div className="mt-2 flex items-center space-x-4 text-sm text-slate-600">
                                      <span className="flex items-center">
                                        <Clock className="w-4 h-4 mr-1" />
                                        {interviewDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                      </span>
                                      <span className="flex items-center">
                                        <Timer className="w-4 h-4 mr-1" />
                                        {interview.duration_minutes} min
                                      </span>
                                      <span className="flex items-center">
                                        <Video className="w-4 h-4 mr-1" />
                                        {interview.interview_type}
                                      </span>
                                    </div>
                                  </div>
                                  <div className="flex space-x-2">
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => handleMonitorInterview(interview)}
                                    >
                                      <Eye className="w-4 h-4 mr-2" />
                                      Monitor
                                    </Button>
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => window.open(`/recordings/${interview.id}`, '_blank')}
                                    >
                                      <Video className="w-4 h-4 mr-2" />
                                      View Recordings
                                    </Button>
                                    <Button 
                                      size="sm"
                                      onClick={() => {
                                        // Add reschedule functionality
                                      }}
                                    >
                                      <Edit className="w-4 h-4 mr-2" />
                                      Reschedule
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <CalendarIcon className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-slate-600 mb-2">No Upcoming Interviews</h3>
                        <p className="text-slate-500">Interviews will appear here once scheduled</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-white">
                  <CardHeader>
                    <CardTitle className="text-slate-800">Recent Activity</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-slate-600">Applications (30 days)</span>
                        <span className="font-medium text-slate-800">{analytics.recent_activity?.applications_30_days || 0}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-600">Hires (30 days)</span>
                        <span className="font-medium text-slate-800">{analytics.recent_activity?.hires_30_days || 0}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// Job Card Component
const JobCard = ({ job }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'draft': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'paused': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'closed': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold text-slate-800 mb-2 group-hover:text-purple-700 transition-colors">{job.title}</h3>
            <div className="flex items-center space-x-4 text-sm text-slate-600">
              <div className="flex items-center space-x-1">
                <MapPin className="w-4 h-4" />
                <span>{job.location}</span>
              </div>
              <div className="flex items-center space-x-1">
                <DollarSign className="w-4 h-4" />
                <span>${job.salary_min?.toLocaleString()} - ${job.salary_max?.toLocaleString()}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>{job.posted_date ? new Date(job.posted_date).toLocaleDateString() : 'Draft'}</span>
              </div>
            </div>
          </div>
          <Badge className={`${getStatusColor(job.status)} border font-medium`}>
            {job.status}
          </Badge>
        </div>

        <p className="text-slate-600 mb-4">{job.description}</p>

        <div className="mb-4">
          <h4 className="font-medium text-slate-800 mb-2">Skills Required:</h4>
          <div className="flex flex-wrap gap-2">
            {job.skills?.map((skill, index) => (
              <Badge key={index} variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                {skill}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex space-x-3">
          <Button variant="outline" size="sm" className="border-purple-300 text-purple-700 hover:bg-purple-50">
            <Edit className="w-4 h-4 mr-2" />
            Edit
          </Button>
          {job.status === 'draft' && (
            <Button size="sm" className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white">
              Publish Job
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Candidate Card Component
const CandidateCard = ({ candidate }) => {
  const viewResume = async () => {
    try {
      const resp = await axios.get(`${API}/candidates/${candidate.id}/resume`, {
        responseType: 'blob',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` }
      });
      const blob = new Blob([resp.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${candidate.full_name || 'candidate'}_resume`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      const msg = error.response?.data?.detail || (error.response?.status === 403
        ? 'Resume is accessible only when the candidate has applied to your company.'
        : 'Resume not available');
      alert(msg);
    }
  };

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-r from-teal-500 to-teal-600 rounded-xl flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-slate-800 group-hover:text-teal-700 transition-colors">{candidate.full_name}</h3>
              <p className="text-slate-600">{candidate.current_title} at {candidate.current_company}</p>
              <div className="flex items-center space-x-4 text-sm text-slate-500 mt-1">
                <div className="flex items-center space-x-1">
                  <Mail className="w-4 h-4" />
                  <span>{candidate.email}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <MapPin className="w-4 h-4" />
                  <span>{candidate.location}</span>
                </div>
              </div>
            </div>
          </div>
          <Badge variant="secondary" className="bg-teal-100 text-teal-800 border-teal-200">{candidate.experience_years}+ years</Badge>
        </div>

        <div className="mb-4">
          <h4 className="font-medium text-slate-800 mb-2">Skills:</h4>
          <div className="flex flex-wrap gap-2">
            {candidate.skills?.map((skill, index) => (
              <Badge key={index} variant="outline" className="text-xs bg-teal-50 text-teal-700 border-teal-200">
                {skill}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex space-x-3">
          <Button variant="outline" size="sm" className="border-teal-300 text-teal-700 hover:bg-teal-50">
            <FileText className="w-4 h-4 mr-2" />
            View Resume
          </Button>
          <Button variant="outline" size="sm" onClick={viewResume} className="border-blue-300 text-blue-700 hover:bg-blue-50">
            <Eye className="w-4 h-4 mr-2" />
            View Resume
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white">
            Add to Job
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Application Card Component
const ApplicationCard = ({ application, candidate, job }) => {
  const getStageColor = (stage) => {
    switch (stage) {
      case 'new': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'screening': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'phone_screen': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'technical_interview': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'final_interview': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'offer': return 'bg-green-100 text-green-800 border-green-200';
      case 'hired': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (!candidate || !job) return null;

  // Download/view candidate resume for this application
  const viewResume = async () => {
    try {
      const resp = await axios.get(`${API}/candidates/${candidate.id}/resume`, {
        responseType: 'blob',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('secuhire_token')}` }
      });
      const blob = new Blob([resp.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${candidate.full_name || 'candidate'}_resume`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      const msg = error.response?.data?.detail || (error.response?.status === 403
        ? 'Resume is accessible only when the candidate has applied to your company.'
        : 'Resume not available');
      alert(msg);
    }
  };

  return (
    <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-slate-800 group-hover:text-orange-700 transition-colors">{candidate.full_name}</h3>
            <p className="text-slate-600">Applied for {job.title}</p>
            <p className="text-sm text-slate-500">Applied on {new Date(application.applied_date).toLocaleDateString()}</p>
          </div>
          <Badge className={`${getStageColor(application.stage)} border font-medium`}>
            {application.stage.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
          </Badge>
        </div>

        <div className="flex items-center space-x-4 text-sm text-slate-600 mb-4">
          <div className="flex items-center space-x-1">
            <Mail className="w-4 h-4" />
            <span>{candidate.email}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Phone className="w-4 h-4" />
            <span>{candidate.phone}</span>
          </div>
        </div>

        <div className="flex space-x-3">
          <Button variant="outline" size="sm" className="border-orange-300 text-orange-700 hover:bg-orange-50">
            <FileText className="w-4 h-4 mr-2" />
            View Profile
          </Button>
          <Button variant="outline" size="sm" onClick={viewResume} className="border-blue-300 text-blue-700 hover:bg-blue-50">
            <Eye className="w-4 h-4 mr-2" />
            View Resume
          </Button>
          <Button size="sm" className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white">
            Move Stage
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Main App Component
function App() {
  const { token, loading, user, userRole } = useAuth();

  console.log('App render - Token:', token ? 'exists' : 'none', 'Loading:', loading, 'User:', user?.full_name, 'Role:', userRole);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-teal-50">
        <div className="relative">
          <Shield className="w-12 h-12 text-purple-600 animate-spin" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-orange-400 to-pink-500 rounded-full animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
        <Routes>
          <Route path="/" element={token ? <Navigate to="/dashboard" replace /> : <LandingPage />} />
          <Route path="/pricing" element={token ? <Navigate to="/dashboard" replace /> : <PricingPage />} />
          <Route path="/auth" element={token ? <Navigate to="/dashboard" replace /> : <AuthPage />} />
          {/* Proctoring routes */}
          <Route path="/proctor/setup" element={<ProctorSetup />} />
          <Route path="/phone-join" element={<PhoneJoinPage />} />
          <Route path="/interviewer/:sessionId" element={<InterviewerRouteWrapper />} />
          {/* Aptitude Test Module (candidate only) */}
          <Route
            path="/aptitude/*"
            element={
              token ? (
                userRole === 'candidate' ? <AptitudeApp /> : <Navigate to="/dashboard" replace />
              ) : (
                <Navigate to="/auth" replace />
              )
            }
          />
          <Route 
            path="/dashboard" 
            element={
              token ? 
                (userRole === 'recruiter' ? <ATSDashboard /> : <CandidateDashboard />) : 
                <Navigate to="/auth" replace />
            } 
          />
          <Route
            path="/recordings/:interviewId"
            element={
              token ? (
                userRole === 'recruiter' ? <RecordingsViewer /> : <Navigate to="/dashboard" replace />
              ) : (
                <Navigate to="/auth" replace />
              )
            }
          />
          <Route
            path="/recruiter/interviews"
            element={
              token ? (
                userRole === 'recruiter' ? <RecruiterInterviews /> : <Navigate to="/dashboard" replace />
              ) : (
                <Navigate to="/auth" replace />
              )
            }
          />
          <Route
            path="/candidate/video-upload"
            element={<CandidateVideoUploadPage />}
          />
          <Route
            path="/recruiter/videos"
            element={<RecruiterVideosPage />}
          />
        </Routes>
      {/* Floating button removed per request */}
    </div>
  );
}

function InterviewerRouteWrapper() {
  const sid = window.location.pathname.split('/').pop();
  return <InterviewerProctor sessionId={sid} />;
}

// Candidate page to upload a video to Firebase
function CandidateVideoUploadPage() {
  const { user, userRole } = useAuth();
  if (!user) return <Navigate to="/auth" replace />;
  if (userRole !== 'candidate') return <Navigate to="/dashboard" replace />;
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50 p-6">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Upload Interview Video</CardTitle>
            <CardDescription>Record or select a video and upload it. The link will be available to recruiters.</CardDescription>
          </CardHeader>
          <CardContent>
            <VideoUpload
              candidateId={user.id}
              candidateEmail={user.email}
              fullName={user.full_name}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Recruiter page to list and stream candidate videos
function RecruiterVideosPage() {
  const { user, userRole, company } = useAuth();
  if (!user) return <Navigate to="/auth" replace />;
  if (userRole !== 'recruiter') return <Navigate to="/dashboard" replace />;
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50 p-6">
      <div className="max-w-5xl mx-auto">
        <Card className="shadow-2xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader>
            <CardTitle>Candidate Video Submissions</CardTitle>
            <CardDescription>Videos are streamed directly from Firebase Storage.</CardDescription>
          </CardHeader>
          <CardContent>
            <VideoList filters={{ companyId: company?.id }} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function AppWithAuth() {
  return (
    <AuthProvider>
      <App />
    </AuthProvider>
  );
}

export default AppWithAuth;
